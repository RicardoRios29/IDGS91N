-- Tablas de dimensiones
CREATE TABLE d_fecha (
    id_fecha DATE PRIMARY KEY,
    anio INTEGER NOT NULL,
    mes INTEGER NOT NULL,
    nombre_mes VARCHAR(20),
    trimestre INTEGER
);

CREATE TABLE d_tipo_viajero (
    id_tipo_viajero SERIAL PRIMARY KEY,
    tipo_viajero VARCHAR(100) UNIQUE NOT NULL
);

CREATE TABLE d_sentido_viaje (
    id_sentido SERIAL PRIMARY KEY,
    sentido VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE d_nacionalidad (
    id_nacionalidad SERIAL PRIMARY KEY,
    nacionalidad VARCHAR(150) UNIQUE NOT NULL,
    codigo_iso VARCHAR(10)
);

CREATE TABLE d_tipo_visa (
    id_visa SERIAL PRIMARY KEY,
    tipo_visa VARCHAR(150) UNIQUE NOT NULL
);

CREATE TABLE d_pais_origen (
    id_pais SERIAL PRIMARY KEY,
    nombre_pais VARCHAR(150) UNIQUE NOT NULL,
    codigo_iso VARCHAR(10),
    zona_geografica VARCHAR(100)
);

CREATE TABLE d_estado_registro (
    id_estado SERIAL PRIMARY KEY,
    estado_registro VARCHAR(50) UNIQUE NOT NULL
);

-- Tabla de hechos
CREATE TABLE h_migracion (
    id_migracion SERIAL PRIMARY KEY,
    id_fecha DATE NOT NULL,
    id_tipo_viajero INTEGER NOT NULL,
    id_sentido INTEGER NOT NULL,
    id_nacionalidad INTEGER NOT NULL,
    id_visa INTEGER NOT NULL,
    id_pais INTEGER NOT NULL,
    id_estado INTEGER NOT NULL,
    estimado BIGINT NOT NULL,
    error_estandar BIGINT,
    CONSTRAINT fk_fecha FOREIGN KEY (id_fecha) REFERENCES d_fecha(id_fecha),
    CONSTRAINT fk_viajero FOREIGN KEY (id_tipo_viajero) REFERENCES d_tipo_viajero(id_tipo_viajero),
    CONSTRAINT fk_sentido FOREIGN KEY (id_sentido) REFERENCES d_sentido_viaje(id_sentido),
    CONSTRAINT fk_nacional FOREIGN KEY (id_nacionalidad) REFERENCES d_nacionalidad(id_nacionalidad),
    CONSTRAINT fk_visa FOREIGN KEY (id_visa) REFERENCES d_tipo_visa(id_visa),
    CONSTRAINT fk_pais FOREIGN KEY (id_pais) REFERENCES d_pais_origen(id_pais),
    CONSTRAINT fk_estado FOREIGN KEY (id_estado) REFERENCES d_estado_registro(id_estado)
);
