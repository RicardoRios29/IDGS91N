from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, confusion_matrix, f1_score, accuracy_score, precision_score, recall_score, roc_auc_score, roc_curve, auc
import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

# Cargar el archivo CSV (ajusta el nombre del archivo si es diferente)
df = pd.read_csv('Matriz.csv')

# Seleccionar variables predictoras y variable objetivo
X = df[['glucosa', 'edad']]       # Variables independientes
y = df['etiqueta']                # Variable dependiente (binaria)

# Dividir en entrenamiento (70%) y prueba (30%)
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.3,
    random_state=42,     # Para reproducibilidad
    stratify=y           # Para mantener el equilibrio de clases
)

# Crear el objeto escalador
scaler = MinMaxScaler()

# Ajustar el escalador con los datos de entrenamiento y transformar ambos conjuntos
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Lista de valores de k a probar
valores_k = [3, 5, 7]

# Diccionario para guardar los F1-scores de cada k
f1_scores = {}

for k in valores_k:
    print(f"\nEntrenando modelo con k = {k}")
    
    # Inicializar el clasificador con el valor actual de k
    knn = KNeighborsClassifier(n_neighbors=k)
    
    # Entrenar el modelo
    knn.fit(X_train_scaled, y_train)
    
    # Realizar predicciones sobre el conjunto de prueba
    y_pred = knn.predict(X_test_scaled)
    
    # Mostrar métricas de clasificación
    print("Reporte de clasificación:")
    print(classification_report(y_test, y_pred))
    
    # Guardar F1-score para comparación
    f1 = f1_score(y_test, y_pred, average='binary')  # O 'macro' si tus clases están desbalanceadas
    f1_scores[k] = f1

# Mostrar los F1-scores resumidos
print("\nResumen de F1-scores por valor de k:")
for k, score in f1_scores.items():
    print(f"k = {k}: F1-score = {score:.4f}")

# Usamos el mejor valor de k (puedes reemplazarlo por el valor elegido)
mejor_k = 5
modelo_final = KNeighborsClassifier(n_neighbors=mejor_k)
modelo_final.fit(X_train_scaled, y_train)
y_pred_final = modelo_final.predict(X_test_scaled)
y_proba_final = modelo_final.predict_proba(X_test_scaled)[:, 1]  # Para ROC-AUC

# Cálculo de métricas
accuracy = accuracy_score(y_test, y_pred_final)
precision = precision_score(y_test, y_pred_final)
recall = recall_score(y_test, y_pred_final)
f1 = f1_score(y_test, y_pred_final)
roc_auc = roc_auc_score(y_test, y_proba_final)

# Resultados
print("Métricas del modelo seleccionado (k = {}):".format(mejor_k))
print(f"Accuracy:  {accuracy:.4f}")
print(f"Precision: {precision:.4f}")
print(f"Recall:    {recall:.4f}")
print(f"F1-score:  {f1:.4f}")
print(f"ROC-AUC:   {roc_auc:.4f}")

# Matriz de confusión
cm = confusion_matrix(y_test, y_pred_final)
plt.figure(figsize=(6, 5))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', cbar=False,
            xticklabels=['Predicho 0', 'Predicho 1'],
            yticklabels=['Real 0', 'Real 1'])
plt.title(f'Matriz de Confusión (k = {mejor_k})')
plt.xlabel('Etiqueta predicha')
plt.ylabel('Etiqueta real')
plt.tight_layout()
plt.show()

# Curva ROC
fpr, tpr, thresholds = roc_curve(y_test, y_proba_final)
roc_auc = auc(fpr, tpr)

plt.figure(figsize=(6, 5))
plt.plot(fpr, tpr, color='darkorange', lw=2, label=f'Curva ROC (AUC = {roc_auc:.4f})')
plt.plot([0, 1], [0, 1], color='gray', linestyle='--', lw=1)
plt.xlabel('Tasa de falsos positivos (FPR)')
plt.ylabel('Tasa de verdaderos positivos (TPR)')
plt.title(f'Curva ROC – Modelo KNN (k = {mejor_k})')
plt.legend(loc='lower right')
plt.tight_layout()
plt.show()